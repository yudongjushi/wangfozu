<?php
namespace Admin\Controller;
use Think\Controller;
//生成admin  login 类
class LoginController extends Controller{
    
    //登录
    
    public function login(){
      
      
        if(IS_POST){
            $yzm=htmlspecialchars(trim(I('post.verify')));
            $admin_name=htmlspecialchars(trim(I('post.admin_name')));
            $pwd=htmlspecialchars(trim(I('post.password')));
            $verify = new \Think\Verify();
            
         
            if(!$verify->check($yzm)){
                $this->error("验证码错误,<br>请更换验证码重新验证",U("Login/login"));
            }else{
                $pwd=md5(sha1($pwd));
                $model=M('admin');
                $admin=$model->where(array('admin_name'=>$admin_name,'admin_pwd'=>$pwd))->find();
                
              
                if ($admin) {
                    unset($pwd);
                    session('admin_id',$admin['id']);
                    session('admin_name',$admin['admin_name']);
                    $date['last_login_time']=date('Y-m-d H:i:s');
                    $res=$model->where(array('id'=>$admin['id']))->save($date);
                    if($res){
                        $this->redirect('index/index');
                    }else{
                        $this->error('系统错误');
                    }
                }else{
                    $this->error('帐号或密码错误',U("Login/login"));
                }
            }
        }
        
        $this->display();
        
    }
    
    //验证码
    public function verify(){
        $Verify =     new \Think\Verify();
        $Verify->fontSize = 50;
        $Verify->length   = 3;
        $Verify->useNoise = false;
        $Verify->entry();
    }
    
    
    
}











?>