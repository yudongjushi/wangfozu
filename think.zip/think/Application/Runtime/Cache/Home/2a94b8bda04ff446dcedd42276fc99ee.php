<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo (C("db_charset")); ?>" />
<title><?php echo ($date["content"]); ?></title>
</head>

<body>

<li><?php echo ($date['date']); ?></li>

<li><?php echo (C("db_charset")); ?></li>
</body>
</html>